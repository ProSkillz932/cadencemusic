import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Outlet } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import Login from './pages/Login';
import Register from './pages/Register';
import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';
import ProtectedRoute from '@/components/ProtectedRoute';
import { useAppAuth } from '@/lib/useAppAuth';
import { Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Upload from './pages/Upload';
import Legal from './pages/Legal';
import Start from './pages/Start';
import Support from './pages/Support';
import Recommend from './pages/Recommend';
import AdminDashboard from './pages/AdminDashboard';
import Forum from './pages/Forum';
import CommunityDetail from './pages/CommunityDetail';
import Profile from './pages/Profile';
import Library from './pages/Library';
import SheetMusicView from './pages/SheetMusicView';
import Subscriptions from './pages/Subscriptions';
import PostDetail from './pages/PostDetail';

// Guard that allows both platform-auth users AND admin session
const AppProtectedRoute = () => {
  const { isLoggedIn, isLoadingAuth } = useAppAuth();
  if (isLoadingAuth) return <div className="fixed inset-0 flex items-center justify-center"><div className="w-6 h-6 border-2 border-muted-foreground border-t-transparent rounded-full animate-spin" /></div>;
  if (!isLoggedIn) return <Navigate to="/" replace />;
  return <Outlet />;
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route path="/" element={<Start />} />
      <Route path="/legal" element={<Layout><Legal /></Layout>} />
      <Route element={<AppProtectedRoute />}>
        <Route element={<Layout />}>
          <Route path="/library" element={<Library />} />
          <Route path="/view/:id" element={<SheetMusicView />} />
          <Route path="/subscriptions" element={<Subscriptions />} />
          <Route path="/upload" element={<Upload />} />
          <Route path="/recommend" element={<Recommend />} />
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/forum" element={<Forum />} />
          <Route path="/post/:postId" element={<PostDetail />} />
          <Route path="/community/:id" element={<CommunityDetail />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/support" element={<Support />} />
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App